
const express = require('express');

const Portfolio = require('../models/Portfolio');
const Skill = require('../models/Skill');
const Project = require('../models/Project');

const {
    ensureAuthenticated,
    ensureAdmin
} = require('../middlewares/auth');

const router = express.Router();

// Public portfolio profile
router.get('/profile', async (req, res, next) => {
    try {
        const profile = await Portfolio.findOne();
        res.json(profile || {});
    } catch (err) {
        next(err);
    }
});

// Update portfolio profile - Admin only
router.put(
    '/profile',
    ensureAuthenticated,
    ensureAdmin,
    async (req, res, next) => {
        try {
            const allowed = [
                'name', 'title', 'bio', 'location',
                'website', 'github', 'linkedin'
            ];

            const data = {};

            for (const field of allowed) {
                if (req.body[field] !== undefined) {
                    data[field] = req.body[field];
                }
            }

            const profile = await Portfolio.findOneAndUpdate(
                {},
                { $set: data },
                {
                    new: true,
                    upsert: true,
                    runValidators: true
                }
            );

            res.json(profile);
        } catch (err) {
            next(err);
        }
    }
);

// Public skills
router.get('/skills', async (req, res, next) => {
    try {
        const skills = await Skill.find().sort({
            order: 1,
            name: 1
        });

        res.json(skills);
    } catch (err) {
        next(err);
    }
});

// Create skill - Admin only
router.post(
    '/skills',
    ensureAuthenticated,
    ensureAdmin,
    async (req, res, next) => {
        try {
            const skill = await Skill.create({
                name: req.body.name,
                category: req.body.category,
                level: req.body.level,
                description: req.body.description,
                order: req.body.order
            });

            res.status(201).json(skill);
        } catch (err) {
            next(err);
        }
    }
);

// Delete skill - Admin only
router.delete(
    '/skills/:id',
    ensureAuthenticated,
    ensureAdmin,
    async (req, res, next) => {
        try {
            const skill = await Skill.findByIdAndDelete(req.params.id);

            if (!skill) {
                return res.status(404).json({
                    message: 'Skill not found'
                });
            }

            res.json({
                message: 'Skill deleted'
            });
        } catch (err) {
            next(err);
        }
    }
);

// Public projects
router.get('/projects', async (req, res, next) => {
    try {
        const projects = await Project.find().sort({
            order: 1,
            createdAt: -1
        });

        res.json(projects);
    } catch (err) {
        next(err);
    }
});

// Create project - Admin only
router.post(
    '/projects',
    ensureAuthenticated,
    ensureAdmin,
    async (req, res, next) => {
        try {
            const project = await Project.create({
                title: req.body.title,
                description: req.body.description,
                technologies: req.body.technologies,
                image: req.body.image,
                github: req.body.github,
                demo: req.body.demo,
                featured: req.body.featured,
                order: req.body.order
            });

            res.status(201).json(project);
        } catch (err) {
            next(err);
        }
    }
);

// Delete project - Admin only
router.delete(
    '/projects/:id',
    ensureAuthenticated,
    ensureAdmin,
    async (req, res, next) => {
        try {
            const project = await Project.findByIdAndDelete(req.params.id);

            if (!project) {
                return res.status(404).json({
                    message: 'Project not found'
                });
            }

            res.json({
                message: 'Project deleted'
            });
        } catch (err) {
            next(err);
        }
    }
);

module.exports = router;
