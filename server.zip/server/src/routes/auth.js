const express = require('express');
const argon2 = require('argon2');
const User = require('../models/User');

const { rateLimit } = require('express-rate-limit');

const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 20,
    standardHeaders: 'draft-8',
    legacyHeaders: false,
    message: {
        message: 'Too many login attempts. Please try again later.'
    }
});

const router = express.Router();
const crypto = require('crypto');
const RefreshToken = require('../models/RefreshToken');
const passport = require('passport');
const {
    createAccessToken,
    createRefreshToken,
    hashToken,
    setAuthCookies,
    clearAuthCookies
} = require('../utils/tokens');

// Register a new user
router.post('/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;

        if (!username || !email || !password) {
            return res.status(400).json({
                message: 'All fields are required'
            });
        }

        if (
            typeof username !== 'string' ||
            typeof email !== 'string' ||
            typeof password !== 'string' ||
            username.trim().length < 3 ||
            username.trim().length > 50 ||
            !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ||
            password.length < 8 ||
            Buffer.byteLength(password, 'utf8') > 1024
        ) {
            return res.status(400).json({
                message: 'Invalid registration information'
            });
        }

        const existingUser = await User.findOne({
            $or: [
                { username: username.trim() },
                { email: email.trim().toLowerCase() }
            ]
        });

        if (existingUser) {
            return res.status(409).json({
                message: 'Username or email is already registered'
            });
        }

        // Hash password before saving
        const hashedPassword = await argon2.hash(password, {
            type: argon2.argon2id
        });

        const user = new User({
            username: username.trim(),
            email: email.trim().toLowerCase(),
            password: hashedPassword,
            role: 'user'
        });

        await user.save();

        res.status(201).json({
            message: 'User registered successfully',
            user: {
                id: user._id,
                username: user.username,
                email: user.email,
                role: user.role
            }
        });

    } catch (err) {
        console.error('Registration error:', err);

        if (err.code === 11000) {
            return res.status(409).json({
                message: 'Username or email is already registered'
            });
        }

        res.status(500).json({
            message: 'Server error'
        });
    }
});

// Login with email and password

router.post('/login', loginLimiter, async (req, res, next) => {
    try {
        const { email, password } = req.body;

        if (
            typeof email !== 'string' ||
            typeof password !== 'string' ||
            !email.trim() ||
            !password
        ) {
            return res.status(400).json({
                message: 'Email and password are required'
            });
        }

        const user = await User.findOne({
            email: email.trim().toLowerCase()
        });

        // Same error message for invalid credentials
        if (!user || !user.password) {
            return res.status(401).json({
                message: 'Invalid email or password'
            });
        }

        // Check account lock
        if (user.lockedUntil && user.lockedUntil > new Date()) {
            return res.status(429).json({
                message: 'Account temporarily locked. Try again later.'
            });
        }

        // Verify password
        const isValid = await argon2.verify(
            user.password,
            password
        );

        if (!isValid) {
            if (user.lockedUntil) {
                user.failedLoginAttempts = 0;
                user.lockedUntil = null;
            }

            user.failedLoginAttempts += 1;

            if (user.failedLoginAttempts >= 5) {
                user.lockedUntil = new Date(
                    Date.now() + 15 * 60 * 1000
                );
            }

            await user.save();

            return res.status(401).json({
                message: 'Invalid email or password'
            });
        }

        // Reset failed login attempts
        user.failedLoginAttempts = 0;
        user.lockedUntil = null;
        await user.save();

        // Regenerate session ID after login
        req.session.regenerate(async (err) => {
            if (err) {
                return next(err);
            }

            try {
                req.session.csrfToken =
                    crypto.randomBytes(32).toString('hex');

                await new Promise((resolve, reject) => {
                    req.session.save(saveErr => {
                        if (saveErr) reject(saveErr);
                        else resolve();
                    });
                });

                // Generate authentication tokens
                const accessToken = createAccessToken(user);
                const refreshToken = await createRefreshToken(user);

                setAuthCookies(res, accessToken, refreshToken);

                res.json({
                    message: 'Login successful',
                    user: {
                        id: user._id,
                        username: user.username,
                        email: user.email,
                        role: user.role
                    },
                    csrfToken: req.session.csrfToken
                });

            } catch (error) {
                next(error);
            }
        });

    } catch (err) {
        next(err);
    }
});



// Refresh access token
router.post('/refresh', async (req, res) => {
    try {
        const token = req.cookies.refreshToken;

        if (!token) {
            return res.status(401).json({
                message: 'Refresh token required'
            });
        }

        const oldToken = await RefreshToken.findOneAndDelete({
            tokenHash: hashToken(token),
            expiresAt: { $gt: new Date() }
        });

        if (!oldToken) {
            clearAuthCookies(res);

            return res.status(401).json({
                message: 'Invalid or expired refresh token'
            });
        }

        const user = await User.findById(oldToken.user);

        if (!user) {
            clearAuthCookies(res);

            return res.status(401).json({
                message: 'User not found'
            });
        }

        // Create a new token pair
        const accessToken = createAccessToken(user);
        const refreshToken = await createRefreshToken(user);

        setAuthCookies(res, accessToken, refreshToken);

        res.json({
            message: 'Token refreshed successfully'
        });

    } catch (err) {
        console.error('Refresh token error:', err);

        res.status(500).json({
            message: 'Server error'
        });
    }
});


// Logout
router.post('/logout', async (req, res) => {
    try {
        const token = req.cookies.refreshToken;

        if (token) {
            await RefreshToken.deleteOne({
                tokenHash: hashToken(token)
            });
        }

        clearAuthCookies(res);

        res.json({
            message: 'Logout successful'
        });

    } catch (err) {
        console.error('Logout error:', err);

        res.status(500).json({
            message: 'Server error'
        });
    }
});

// Get CSRF token
router.get('/csrf', (req, res) => {
    if (!req.session.csrfToken) {
        req.session.csrfToken = crypto.randomBytes(32).toString('hex');
    }

    res.json({
        csrfToken: req.session.csrfToken
    });
});


// Login with Google
router.get('/google',
    loginLimiter,
    passport.authenticate('google', {
        scope: ['profile', 'email']
    })
);

// Google OAuth callback
router.get('/google/callback', (req, res, next) => {
    passport.authenticate('google', {
        session: false
    }, async (err, user) => {
        if (err) {
            return next(err);
        }

        if (!user) {
            return res.redirect('/cprg-312/login?error=google');
        }

        try {
            // Regenerate session ID after successful login
            req.session.regenerate(async (sessionErr) => {
                if (sessionErr) {
                    return next(sessionErr);
                }

                try {
                    // Create a new CSRF token
                    req.session.csrfToken =
                        crypto.randomBytes(32).toString('hex');

                    await new Promise((resolve, reject) => {
                        req.session.save(saveErr => {
                            if (saveErr) reject(saveErr);
                            else resolve();
                        });
                    });

                    // Generate JWT and refresh token
                    const accessToken = createAccessToken(user);
                    const refreshToken = await createRefreshToken(user);

                    setAuthCookies(res, accessToken, refreshToken);

                    res.redirect('/cprg-312/dashboard');

                } catch (error) {
                    next(error);
                }
            });

        } catch (error) {
            next(error);
        }
    })(req, res, next);
});


module.exports = router;
